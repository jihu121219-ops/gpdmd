import discord
from discord import app_commands
from discord.ext import commands
import yt_dlp
import asyncio

# 봇 설정
# 주의: 토큰은 절대로 타인에게 노출되지 않도록 하세요! 
# 사진에 노출된 토큰은 디스코드 개발자 포털에서 'Reset Token'을 눌러 새로 발급받는 것이 좋습니다.
TOKEN = "MTQ5MDQ0OTc4Njg3NTE1MDUwOA.G1jqiD.jmul62qTBQgANY3CbYudDc5V4-qiaBK-7isFNo" 

# yt-dlp 옵션 설정
YDL_OPTIONS = {
    'format': 'bestaudio/best',
    'noplaylist': True,
    'quiet': True,
}

FFMPEG_OPTIONS = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn',
}

# 서버별 상태 관리
guild_states = {}

def get_guild_state(guild_id):
    if guild_id not in guild_states:
        guild_states[guild_id] = {
            'volume': 0.5,
            'is_looping': False,
            'current_url': None,
            'current_title': None
        }
    return guild_states[guild_id]

class MusicBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self):
        # 봇이 켜질 때 슬래시 명령어를 디스코드 서버에 즉시 등록 시도
        try:
            synced = await self.tree.sync()
            print(f"동기화 완료: {len(synced)}개의 명령어가 등록되었습니다.")
        except Exception as e:
            print(f"동기화 실패: {e}")

bot = MusicBot()

@bot.event
async def on_ready():
    print(f"로그인 성공: {bot.user.name}")
    print("----------------------------")

def check_queue(error, interaction, vc, guild_id):
    state = get_guild_state(guild_id)
    if error:
        print(f"에러 발생: {error}")
    
    if state['is_looping'] and state['current_url'] and vc.is_connected():
        # 반복 재생 시 별도의 쓰레드에서 비동기 함수 실행
        coro = play_music(interaction, state['current_url'], is_retry=True)
        asyncio.run_coroutine_threadsafe(coro, bot.loop)

async def play_music(interaction, url, is_retry=False):
    guild_id = interaction.guild.id
    state = get_guild_state(guild_id)
    vc = interaction.guild.voice_client

    if not vc: return

    try:
        with yt_dlp.YoutubeDL(YDL_OPTIONS) as ydl:
            info = ydl.extract_info(url, download=False)
            url2 = info['url']
            title = info.get('title', '알 수 없는 곡')
            state['current_url'] = url
            state['current_title'] = title

        source = discord.FFmpegPCMAudio(url2, **FFMPEG_OPTIONS)
        # 볼륨 조절을 위한 Transformer 설정
        transformed_source = discord.PCMVolumeTransformer(source, volume=state['volume'])
        
        if vc.is_playing():
            vc.stop()
            
        vc.play(transformed_source, after=lambda e: check_queue(e, interaction, vc, guild_id))
        
        if not is_retry:
            await interaction.followup.send(f"🎵 **{title}** 재생을 시작합니다! (볼륨: {int(state['volume']*100)}%)")
            
    except Exception as e:
        if not is_retry:
            await interaction.followup.send(f"오류가 발생했습니다: {e}")

@bot.tree.command(name="재생", description="유튜브 음악을 재생합니다.")
async def play(interaction: discord.Interaction, url: str):
    await interaction.response.defer()
    if not interaction.user.voice:
        return await interaction.followup.send("음성 채널에 먼저 들어가주세요!")

    channel = interaction.user.voice.channel
    if interaction.guild.voice_client is None:
        await channel.connect()
    
    await play_music(interaction, url)

@bot.tree.command(name="볼륨", description="0-100 사이로 볼륨을 조절합니다.")
async def volume(interaction: discord.Interaction, 수치: int):
    if not (0 <= 수치 <= 100):
        return await interaction.response.send_message("볼륨은 0~100 사이여야 합니다.")
    
    state = get_guild_state(interaction.guild.id)
    state['volume'] = 수치 / 100
    
    vc = interaction.guild.voice_client
    if vc and vc.source:
        vc.source.volume = state['volume']
        await interaction.response.send_message(f"🔊 볼륨을 **{수치}%**로 변경했습니다.")
    else:
        await interaction.response.send_message(f"설정 완료! 다음 곡부터 **{수치}%** 볼륨으로 재생됩니다.")

@bot.tree.command(name="반복", description="현재 곡 반복 재생을 켜거나 끕니다.")
async def loop(interaction: discord.Interaction):
    state = get_guild_state(interaction.guild.id)
    state['is_looping'] = not state['is_looping']
    status = "활성화" if state['is_looping'] else "비활성화"
    await interaction.response.send_message(f"🔁 반복 재생이 **{status}**되었습니다.")

@bot.tree.command(name="중지", description="재생을 중지하고 봇이 퇴장합니다.")
async def stop(interaction: discord.Interaction):
    if interaction.guild.voice_client:
        await interaction.guild.voice_client.disconnect()
        get_guild_state(interaction.guild.id)['is_looping'] = False
        await interaction.response.send_message("👋 음악을 중지하고 나갑니다.")
    else:
        await interaction.response.send_message("연결된 음성 채널이 없습니다.")

@bot.tree.command(name="건너뛰기", description="현재 곡을 건너뜁니다.")
async def skip(interaction: discord.Interaction):
    vc = interaction.guild.voice_client
    if vc and vc.is_playing():
        vc.stop()
        await interaction.response.send_message("⏭️ 현재 곡을 건너뛰었습니다.")
    else:
        await interaction.response.send_message("재생 중인 곡이 없습니다.")

bot.run(TOKEN)